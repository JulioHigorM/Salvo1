def decimal_para_binario(decimal):
    return bin(decimal)

def decimal_para_hexadecimal(decimal):
    return hex(decimal)

def decimal_para_octal(decimal):
    return oct(decimal)

numero_decimal = int(input("Digite o número decimal: "))

print("O número em binário é:", decimal_para_binario(numero_decimal))
print("O número em hexadecimal é:", decimal_para_hexadecimal(numero_decimal))
print("O número em octal é:", decimal_para_octal(numero_decimal))