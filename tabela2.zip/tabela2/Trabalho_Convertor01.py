def main():
    base_inicial = int(input("Digite  base inicial\n1 - Binário\n2 - Octal\n3 - Decimal\n4 - Hexadecmal: "))
    base_final = float(input("Digite  base final\n1 - Binário\n2 - Octal\n3 - Decimal\n4 - Hexadecmal: "))

    num = input("Digite o número: ")

    conversor_decimal(base_inicial, base_final, num)


def conversor_decimal(base_inicial, base_final, num):
    soma = 0

    if base_inicial == 1:
        b = 2
    elif base_inicial == 2:
        b = 8
    elif base_inicial == 3:
        b = 10
    elif base_inicial == 4:
        b = 16

    num = num[::-1] 

    for i in range(len(num)):
        soma += int(num[i]) * (b**i)

    resultado(soma , base_final)


def resultado(soma , base_final):
    resultado = ""

    if base_final == 1:
        resultado = bin(soma)
    elif base_final == 2:
        resultado = oct(soma)
    elif base_final == 3:
        resultado = soma
    elif base_final == 4:
        resultado = hex(soma)

    return print(f"O número se torna: {resultado[2:]}") 


if __name__ == "__main__":
    main()